<ComposableMap
  projection="geoAzimuthalEqualArea"
  projectionConfig={{
    rotate: [-10.0, -53.0, 0],
    scale: 1200,
  }}
>
  ...
</ComposableMap>
